void __fastcall __noreturn sub_14F7C()
{
  __int64 v0; // rbp
  int v1; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  if ( *(int *)(v0 - 17868) <= 9 )
    snprintf((char *)(v0 - 256), 0xC8u, "./chall $LINENO 8257 %d %d", *(_DWORD *)(v0 - 17872), *(_DWORD *)(v0 - 17868));
  else
    snprintf((char *)(v0 - 256), 0xC8u, "./chall $LINENO 7762 %d %d", *(_DWORD *)(v0 - 17872), *(_DWORD *)(v0 - 17868));
  v1 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  close_and_exit(0);
}
