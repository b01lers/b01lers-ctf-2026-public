void __fastcall __noreturn sub_23139()
{
  __int64 v0; // rbp
  int v1; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  if ( *(_DWORD *)(v0 - 17856) == 33 )
    snprintf(
      (char *)(v0 - 256),
      0xC8u,
      "./chall $LINENO 488 %d %d %d %d %d %d",
      *(_DWORD *)(v0 - 17872),
      *(_DWORD *)(v0 - 17868),
      *(_DWORD *)(v0 - 17864),
      *(_DWORD *)(v0 - 17860),
      *(_DWORD *)(v0 - 17856),
      *(_DWORD *)(v0 - 17852));
  else
    snprintf(
      (char *)(v0 - 256),
      0xC8u,
      "./chall $LINENO 3899 %d %d %d %d %d %d",
      *(_DWORD *)(v0 - 17872),
      *(_DWORD *)(v0 - 17868),
      *(_DWORD *)(v0 - 17864),
      *(_DWORD *)(v0 - 17860),
      *(_DWORD *)(v0 - 17856),
      *(_DWORD *)(v0 - 17852));
  v1 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  close_and_exit(0);
}
