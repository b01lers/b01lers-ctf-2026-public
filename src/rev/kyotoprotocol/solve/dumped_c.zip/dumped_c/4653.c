void __fastcall __noreturn sub_434B3()
{
  __int64 v0; // rbp
  int v1; // eax
  int v2; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  *(_DWORD *)(v0 - 17924) = 38;
  snprintf((char *)(v0 - 256), 0xC8u, "export g_2093=%d", *(_DWORD *)(v0 - 17924));
  v1 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  snprintf((char *)(v0 - 256), 0xC8u, "./chall $LINENO 6031 %d", *(_DWORD *)(v0 - 17872));
  v2 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v2));
  close_and_exit(0);
}
