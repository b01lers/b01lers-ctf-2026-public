void __fastcall __noreturn sub_414BD()
{
  __int64 v0; // rbp
  int v1; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  v1 = dword_ABE98;
  if ( *(_DWORD *)(v0 - 17872) == 54 )
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 544", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  else
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 177", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  close_and_exit(0);
}
