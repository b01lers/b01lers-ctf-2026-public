void __fastcall __noreturn sub_1E907()
{
  __int64 v0; // rbp
  char *v1; // rax
  int v2; // eax
  int v3; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  if ( getenv("i4") )
    v1 = getenv("i4");
  else
    v1 = "0";
  v2 = atoi(v1);
  snprintf(
    (char *)(v0 - 256),
    0xC8u,
    "./chall $LINENO 4766 %d %d %d",
    *(_DWORD *)(v0 - 17872),
    *(_DWORD *)(v0 - 17868),
    v2);
  v3 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v3));
  close_and_exit(0);
}
