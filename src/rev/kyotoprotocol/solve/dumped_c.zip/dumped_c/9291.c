void __fastcall __noreturn sub_2C7B8()
{
  __int64 v0; // rbp
  int v1; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  v1 = dword_ABE98;
  if ( *(_DWORD *)(v0 - 17872) == 68 )
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 2224", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  else
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 3819", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  close_and_exit(0);
}
