void __fastcall __noreturn sub_3FBBA()
{
  __int64 v0; // rbp
  int v1; // eax
  int v2; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  v1 = dword_ABE98++;
  write_line("echo \"Enter the password:\"", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  v2 = dword_ABE98++;
  write_line("./chall $LINENO 2339", (unsigned int)(*(_DWORD *)(v0 - 17932) + v2));
  close_and_exit(0);
}
