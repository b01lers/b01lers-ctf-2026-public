void __fastcall __noreturn sub_2E6AF()
{
  __int64 v0; // rbp
  int v1; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  v1 = dword_ABE98;
  if ( *(_DWORD *)(v0 - 17872) == 106 )
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 8500", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  else
  {
    ++dword_ABE98;
    write_line("./chall $LINENO 2890", (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
  }
  close_and_exit(0);
}
