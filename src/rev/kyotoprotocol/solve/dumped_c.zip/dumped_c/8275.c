void __fastcall __noreturn sub_30FAD()
{
  __int64 v0; // rbp
  int v1; // eax
  int v2; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  *(_QWORD *)(v0 - 17920) = getenv("input");
  if ( !*(_QWORD *)(v0 - 17920) )
  {
    write_header();
    close_and_exit(0);
  }
  *(_DWORD *)(v0 - 17944) = 0;
  while ( **(_BYTE **)(v0 - 17920) )
  {
    snprintf((char *)(v0 - 308), 0xAu, "i%d", *(_DWORD *)(v0 - 17944));
    snprintf((char *)(v0 - 298), 0xAu, "%u", **(char **)(v0 - 17920));
    snprintf((char *)(v0 - 256), 0xC8u, "export %s=%s", (const char *)(v0 - 308), (const char *)(v0 - 298));
    v1 = dword_ABE98++;
    write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v1));
    ++*(_DWORD *)(v0 - 17944);
    ++*(_QWORD *)(v0 - 17920);
  }
  v2 = dword_ABE98++;
  write_line("./chall $LINENO 8947", (unsigned int)(*(_DWORD *)(v0 - 17932) + v2));
  close_and_exit(0);
}
