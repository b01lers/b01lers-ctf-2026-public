void __fastcall __noreturn sub_496A4()
{
  __int64 v0; // rbp
  char *v1; // rax
  int v2; // eax
  int v3; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  if ( getenv("g_2184") )
    v1 = getenv("g_2184");
  else
    v1 = "0";
  *(_DWORD *)(v0 - 17924) = atoi(v1) + 100;
  snprintf((char *)(v0 - 256), 0xC8u, "export g_2184=%d", *(_DWORD *)(v0 - 17924));
  v2 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v2));
  v3 = dword_ABE98++;
  write_line("./chall $LINENO 139", (unsigned int)(*(_DWORD *)(v0 - 17932) + v3));
  close_and_exit(0);
}
