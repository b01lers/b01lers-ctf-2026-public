void __fastcall __noreturn sub_15DAA()
{
  __int64 v0; // rbp
  char *v1; // rax
  int v2; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  if ( getenv("g_9342") )
    v1 = getenv("g_9342");
  else
    v1 = "0";
  *(_DWORD *)(v0 - 17872) = atoi(v1) + 10;
  snprintf((char *)(v0 - 256), 0xC8u, "./chall $LINENO 587 %d", *(_DWORD *)(v0 - 17872));
  v2 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v2));
  close_and_exit(0);
}
