void __fastcall __noreturn sub_26134()
{
  __int64 v0; // rbp

  sub_A762(*(unsigned int *)(v0 - 17932));
  write_header();
  close_and_exit(0);
}
