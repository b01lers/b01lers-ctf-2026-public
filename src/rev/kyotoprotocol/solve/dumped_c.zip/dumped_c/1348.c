void __fastcall __noreturn sub_22E7B()
{
  __int64 v0; // rbp

  close_and_exit(*(unsigned int *)(v0 - 17872));
}
