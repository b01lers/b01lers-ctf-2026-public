void __fastcall __noreturn sub_31AAE()
{
  __int64 v0; // rbp
  int v1; // ebx
  char *v2; // rax
  int v3; // eax
  int v4; // eax

  sub_A762(*(unsigned int *)(v0 - 17932));
  v1 = *(_DWORD *)(v0 - 17852);
  if ( getenv("g_4387") )
    v2 = getenv("g_4387");
  else
    v2 = "0";
  v3 = atoi(v2);
  snprintf(
    (char *)(v0 - 256),
    0xC8u,
    "./chall $LINENO 6775 %d %d %d %d %d %d",
    *(_DWORD *)(v0 - 17872),
    *(_DWORD *)(v0 - 17868),
    *(_DWORD *)(v0 - 17864),
    *(_DWORD *)(v0 - 17860),
    v3,
    v1);
  v4 = dword_ABE98++;
  write_line(v0 - 256, (unsigned int)(*(_DWORD *)(v0 - 17932) + v4));
  close_and_exit(0);
}
